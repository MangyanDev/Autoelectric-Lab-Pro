# PCB Scanner: AI-Powered Auto Track Mapping & Component Datasheet Inspector

Seamless feature extension for the existing **AutoTech Virtual Lab Pro** platform. Adds AI-powered PCB vision detection, auto-copper track mapping, neon net highlighting, and interactive component datasheet & pinout inspection directly into the existing `SchematicPcbScanner.tsx` module.

---

> [!IMPORTANT] Core Preservation Guarantee
> 
> * **Existing App Preservation**: This feature is an additive extension to the existing application. All existing features—including the MNA electrical simulation solver, interactive Harness Wiring canvas, ECU Pinouts photograph, Bench Power Supply, Digital Multimeter (DMM), Oscilloscope, Fault Injector matrix, and automated unit tests—will remain 100% functional and intact.
> * **Vision & Mapping Functionality**: Hybrid AI & Vision Detection (auto-detects ICs, discrete components, traces, and copper nets with normalized bounding boxes, confidence badges, and interactive hover part specs).
> * **Interactive Part Information**: Full Datasheet & Pinout Inspection (reference designators like `U1`, `R12`, IC package types, operating voltage rails, pin breakout tables, and diagnostic test points).
> * **Trace & Copper Visualization**: Neon Trace Net Highlighting (distinct neon-colored copper trace overlays with click-to-trace net connectivity and terminal node markers).

---

## 1. Overview & Core Concept

* **What It Does**: Enhances the existing **PCB / AI Scanner** tab inside AutoTech Virtual Lab Pro. When a technician uploads or selects a PCB photograph or schematic image, the engine performs vision detection to outline component boundaries (ICs, microcontrollers, resistors, capacitors, transistors, diodes), extract reference designators, map copper trace connectivity nets, render neon trace overlays, and open an interactive component datasheet & pinout inspector on click.
* **Target Audience**: Automotive electrical technicians, students, and diagnostic engineers tracing ECU hardware, sensor breakout boards, and automotive electronics.
* **Key Value**: Replaces manual multi-meter probe continuity tracing across complex multi-layer PCBs with automated computer vision track mapping and instant datasheet breakouts.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Accessing the Feature**: The user stays in the existing AutoTech Virtual Lab Pro app and selects the `PCB / AI Scanner` tab from the top navigation bar.
2. **Image Capture / Sample Selection**: The technician uploads a high-resolution PCB photograph, captures via camera, or selects from built-in automotive preset samples (Bosch ME7.5 ECU motherboard, TPS sensor breakout PCB, CAN transceiver module).
3. **AI & Vision Analysis Execution**: The image is validated (MIME type, size $<8\,\text{MB}$) and processed via Gemini Vision / local computer vision feature extractor.
4. **Interactive PCB Canvas Experience**:
   * **Component Bounding Boxes**: Clickable bounding boxes around detected ICs, transistors, connectors, and discrete components with confidence badges.
   * **Neon Copper Trace Net Overlays**: SVG path overlays showing copper traces glowing in neon colors (`#00f3ff`, `#39ff14`, `#ff6600`, `#a855f7`).
   * **Click-to-Trace Net Connectivity**: Clicking any trace or pin highlights the entire connected net across the board.
5. **Interactive Component Datasheet Drawer / Modal**: Clicking any detected component opens a technical datasheet drawer featuring:
   * **Part Specs**: Reference designator (e.g. `U1`), part number (e.g. `Bosch 30343` / `TLE6244X`), package type (e.g. `LQFP-64`, `SOIC-8`), operating voltage range.
   * **Pinout Breakout Table**: Complete pin number, pin name, electrical function, nominal voltage, and diagnostic test point notes.
   * **Verification Status Badge**: Clear designation of verification status (*AI Detected*, *User Reviewed*, *Technician Verified*).

### Visual Identity & Theme
* **Aesthetic Consistency**: Matches the existing clinical dark lab theme (`#07090e` dark slate canvas, `#0f172a` structural panels, 1px hairline borders).
* **Color Palette**:
  * *Canvas Field*: Deep space slate (`#07090e`).
  * *Component Highlight Box*: Phosphor cyan (`#06b6d4`), amber (`#f59e0b`), emerald (`#10b981`).
  * *Neon Trace Overlays*: Neon cyan (`#00f3ff`), neon green (`#39ff14`), neon orange (`#ff6600`).
* **Typography**: Technical sans (`Plus Jakarta Sans` / `DM Sans`) for prose, with tabular monospace (`JetBrains Mono` / `font-mono tabular-nums`) for pin numbers, voltages, coordinates, and bounding box percentages.

---

## 3. Key Product Decisions & Trade-Offs

* **Decision 1: Additive Enhancement of `SchematicPcbScanner.tsx`**
  * *Chosen Approach*: Refactor and extend the existing `/src/components/SchematicPcbScanner.tsx` component rather than adding a separate page or breaking out existing tabs.
  * *Why*: Preserves 100% of existing application state, navigation, solver integration, and layout architecture.

* **Decision 2: Hybrid Vision API & Fallback Preset Rule Engine**
  * *Chosen Approach*: Combine server-side Gemini Vision API image analysis with client-side SVG coordinate normalizers and structured automotive presets.
  * *Why*: Ensures instant interactive rendering, guarantees 100% uptime even when offline or without an API key, and produces reliable bounding boxes normalized to percentages ($x\%, y\%, w\%, h\%$).

* **Decision 3: SVG Vector Overlay Layer over Responsive Canvas Image**
  * *Chosen Approach*: Render an SVG overlay layer directly over the responsive `<img>` element.
  * *Why*: Enables CSS hardware-accelerated neon drop-shadow filters (`filter: drop-shadow(0 0 6px var(--neon-color))`), crisp vector scaling upon zoom/pan, and native click/hover pointer events on individual traces and pins.

---

## 4. Technical Architecture & Data Strategy

### Component Architecture & System Layout

```
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│                             AutoTech Virtual Lab Pro (App.tsx)                           │
│ ┌──────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Top Navigation Bar: [Bench Lab] [Harness Wiring] [ECU Pinouts] [Scope] [PCB Scanner] │ │
│ └──────────────────────────────────────────────────────────────────────────────────────┘ │
│                                            │
│                                            ▼ (Active Tab: PCB Scanner)
│ ┌──────────────────────────────────────────────────────────────────────────────────────┐ │
│ │                             SchematicPcbScanner.tsx                                  │ │
│ │                                                                                      │ │
│ │ ┌──────────────────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Control Toolbar: Sample Presets | Image Upload | Region Crop | Layer Toggle      │ │ │
│ │ └──────────────────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                                      │ │
│ │ ┌──────────────────────────────────────────────┐ ┌─────────────────────────────────┐ │ │
│ │ │ PcbCanvasViewer.tsx                          │ │ PcbDatasheetDrawer.tsx          │ │ │
│ │ │ ┌──────────────────────────────────────────┐ │ │ ┌─────────────────────────────┐ │ │ │
│ │ │ │ <img> Base PCB Photograph                │ │ │ │ Part Specs: U1 (Bosch 30343)  │ │ │ │
│ │ │ └──────────────────────────────────────────┘ │ │ │ Package: LQFP-64              │ │ │ │
│ │ │ ┌──────────────────────────────────────────┐ │ │ ├─────────────────────────────┤ │ │ │
│ │ │ │ <svg> Neon Traces & Bounding Boxes       │ │ │ │ Pinout Breakout Table         │ │ │ │
│ │ │ │  - Connected Copper Nets (Click-to-Trace)│ │ │ │ # | Name | Function | Nominal  │ │ │ │
│ │ │ │  - Interactive Pin Node Markers          │ │ │ │ 1 | VCC  | +5.0V VRef | 5.00V   │ │ │ │
│ │ │ └──────────────────────────────────────────┘ │ │ │ 2 | GND  | Ground     | 0.00V   │ │ │ │
│ │ └──────────────────────────────────────────────┘ │ └─────────────────────────────┘ │ │ │
│ └──────────────────────────────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼ (POST /api/autoelectric/analyze-schematic)
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│                             server.ts (Backend Service)                                  │
│ ┌──────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ Image Payload Validator (MIME + 8MB Max) -> Gemini Image Analysis Provider           │ │
│ └──────────────────────────────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & TypeScript Interfaces

```typescript
export interface PcbComponentPin {
  pinNumber: number;
  pinName: string;
  functionCategory: 'power' | 'ground' | 'signal_in' | 'driver_out' | 'bus';
  nominalVoltage: number;
  connectedNetId: string;
  description: string;
}

export interface PcbDetectedComponent {
  id: string;
  refDes: string; // e.g. "U1", "R12", "C4"
  partName: string; // e.g. "Bosch 30343 Quad Driver IC"
  packageType: string; // e.g. "LQFP-64", "SOIC-8", "0805"
  category: 'ic' | 'resistor' | 'capacitor' | 'transistor' | 'diode' | 'connector';
  confidence: number; // 0.0 to 1.0
  verificationState: 'AI_DETECTED' | 'USER_REVIEWED' | 'TECHNICIAN_VERIFIED';
  boundingBox: {
    xPercent: number;
    yPercent: number;
    widthPercent: number;
    heightPercent: number;
  };
  pins: PcbComponentPin[];
  datasheetNotes: string;
}

export interface PcbTraceNet {
  netId: string; // e.g. "NET_VREF_5V", "NET_TPS_SIG", "NET_CAN_H"
  netName: string;
  colorHex: string;
  connectedComponentPinIds: string[];
  pathCoordinatesPercent: { x: number; y: number }[];
}
```

### Planned Code Updates
1. Extend `src/components/SchematicPcbScanner.tsx` to include the SVG neon trace net layer, component bounding boxes, hover tooltips, and interactive datasheet drawer.
2. Add structured preset automotive datasets (Bosch ME7.5 ECU motherboard, TPS sensor breakout PCB, CAN transceiver module).
3. Connect click-to-trace net connectivity highlighting and component pinout tables.

---

## 5. Verification Plan

* **TypeScript Compilation**: Verify zero errors (`tsc --noEmit`).
* **Automated Unit Tests**: Execute `npm run test` to confirm numerical solver and DMM engine remain 100% operational (28/28 passing).
* **Production Build**: Co-execute `compile_applet` and `lint_applet` to confirm build succeeds.
